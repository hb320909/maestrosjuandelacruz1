# Portal de Residencia Escolar

Aplicación web completa para la gestión de residencia escolar, diseñada para los maestros.

## Características

- **Sistema de login** con usuarios predefinidos
- **Dashboard** con resumen de actividad
- **Gestión de alumnos**: añadir, editar, eliminar y asignar habitaciones
- **Gestión de habitaciones**: visualización y asignación
- **Registro de faltas**: registro y filtrado de incidencias
- **Diseño responsive** y moderno
- **Integración con Supabase** para almacenamiento en la nube
- **Despliegue optimizado** para Vercel

## Usuarios y Contraseñas

| Usuario | Contraseña |
|---------|------------|
| Kati | sun12 |
| Alvaro | rock34 |
| Juan Ignacio | wiz56 |
| Maria Jose | moon78 |
| Jose Antonio | thun90 |
| Lourdes | rain21 |
| Ruben | comet43 |
| Belen | star65 |
| Adolfo | king999 |

## Tecnologías Utilizadas

- **HTML5** - Estructura semántica
- **Tailwind CSS** - Estilos responsive
- **JavaScript Vanilla** - Lógica del frontend
- **Font Awesome** - Iconos
- **Google Fonts** - Tipografía Inter

## Despliegue en Vercel

### Opción 1: Despliegue rápido con Vercel CLI

1. Instala Vercel CLI:
```bash
npm install -g vercel
```

2. Despliega la aplicación:
```bash
vercel
```

### Opción 2: Despliegue manual

1. Crea un repositorio en GitHub
2. Sube los archivos: `index.html`, `app.js`, `package.json`, `vercel.json`
3. Conecta tu repositorio a [Vercel](https://vercel.com)
4. Despliega automáticamente

## Ejecución Local

Para probar la aplicación localmente:

```bash
# Instala las dependencias
npm install

# Configura las variables de entorno
cp .env.example .env
# Edita .env con tus credenciales de Supabase

# Inicia el servidor de desarrollo
npm run dev
```

Abre tu navegador y visita `http://localhost:3000`

## Estructura de Archivos

```
├── index.html          # Página principal con toda la estructura
├── app.js              # Lógica de JavaScript
├── main.js             # Configuración de Supabase
├── styles.css          # Estilos personalizados
├── package.json        # Configuración del proyecto
├── vite.config.js      # Configuración de Vite
├── vercel.json         # Configuración para Vercel
├── .env.example        # Ejemplo de variables de entorno
└── README.md           # Documentación
```

## Funcionalidades por Sección

### Dashboard
- Resumen de alumnos, habitaciones ocupadas y faltas
- Actividad reciente con timestamps
- Estadísticas en tiempo real

### Gestión de Alumnos
- Formulario para añadir nuevos alumnos
- Tabla con lista completa de alumnos
- Fotos generadas automáticamente con UI Avatars
- Editar y eliminar alumnos
- Asignación de habitaciones

### Gestión de Habitaciones
- Visualización de todas las habitaciones
- Estados: vacante, parcialmente ocupada, completa
- Asignación directa desde la cuadrícula
- Capacidad y tipo de habitación

### Registro de Faltas
- Formulario para registrar incidencias
- Filtrado por alumno y fecha
- Lista completa con opciones de eliminación
- Historial completo

### Contacto
- Información de contacto general
- Teléfonos de emergencia
- Horarios de atención

## Características Técnicas

- **Responsive Design**: Funciona en móviles, tablets y desktop
- **Supabase Integration**: Almacenamiento en la nube con sincronización en tiempo real
- **Vite Build System**: Construcción optimizada y hot module replacement
- **Moderno UI**: Interfaz limpia con Tailwind CSS
- **Accesible**: Semántica HTML5 y buena contrastación
- **Animaciones**: Transiciones suaves y micro-interacciones
- **Environment Variables**: Configuración segura con variables de entorno

## Notas del Desarrollo

- La aplicación utiliza Supabase como backend para almacenamiento en la nube
- Los datos se sincronizan automáticamente entre dispositivos
- Las fotos se generan automáticamente usando UI Avatars
- El diseño está optimizado para dispositivos móviles
- Incluye manejo de errores y validaciones básicas
- Configurado para despliegue automático en Vercel
- Soporta variables de entorno para diferentes configuraciones

## Personalización

Para modificar colores o estilos:
- Edita los colores en `index.html`
- Puedes cambiar la tipografía en el tag `<head>`
- Las animaciones están definidas en el CSS personalizado

Para agregar más funcionalidades:
- Extiende la lógica en `app.js`
- Añade nuevas secciones en `index.html`
- Actualiza el menú de navegación

---

Desarrollado para Residencia Escolar San Ignacio#   r e s i 
 
 